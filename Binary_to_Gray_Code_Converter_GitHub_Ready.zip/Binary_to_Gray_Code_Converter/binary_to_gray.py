# 4-bit Binary to Gray Code Converter (Python demo)

def binary_to_gray(binary: int) -> int:
    """Convert a non-negative integer to Gray code."""
    return binary ^ (binary >> 1)

if __name__ == "__main__":
    print("Binary | Gray")
    print("--------------")
    for value in range(16):
        gray = binary_to_gray(value)
        print(f"{value:04b}   | {gray:04b}")
