# 4-Bit Binary to Gray Code Converter

## Project Overview
This Digital Electronics mini project converts a 4-bit binary input into its equivalent 4-bit Gray code output using XOR logic.

## Objective
To understand binary-to-Gray conversion and implement the combinational logic circuit.

## Logic
For binary input `B3 B2 B1 B0`, Gray output `G3 G2 G1 G0` is:

- `G3 = B3`
- `G2 = B3 XOR B2`
- `G1 = B2 XOR B1`
- `G0 = B1 XOR B0`

## Truth Table

| Binary (B3 B2 B1 B0) | Gray (G3 G2 G1 G0) |
|---|---|
| 0000 | 0000 |
| 0001 | 0001 |
| 0010 | 0011 |
| 0011 | 0010 |
| 0100 | 0110 |
| 0101 | 0111 |
| 0110 | 0101 |
| 0111 | 0100 |
| 1000 | 1100 |
| 1001 | 1101 |
| 1010 | 1111 |
| 1011 | 1110 |
| 1100 | 1010 |
| 1101 | 1011 |
| 1110 | 1001 |
| 1111 | 1000 |

## Files
- `binary_to_gray.v` — Verilog design module
- `binary_to_gray_tb.v` — Verilog testbench
- `binary_to_gray.py` — Python demonstration
- `truth_table.csv` — full truth table

## How to Run the Verilog Testbench
Using Icarus Verilog:
```bash
iverilog -o sim binary_to_gray.v binary_to_gray_tb.v
vvp sim
```

## Expected Result
The simulation prints all 16 binary inputs and their corresponding Gray code outputs.

## Applications
- Rotary encoders
- Digital systems where minimizing transition errors is useful
- Analog-to-digital conversion interfaces

## Author
Student Name: [Your Name]
Branch: ECE
Internship Topic: Digital Electronics

> Customize the author details and verify the project according to your internship submission requirements.
