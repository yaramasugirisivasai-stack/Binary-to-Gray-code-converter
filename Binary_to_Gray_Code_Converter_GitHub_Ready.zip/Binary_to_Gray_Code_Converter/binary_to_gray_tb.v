// Testbench for 4-bit Binary to Gray Code Converter
`timescale 1ns/1ps

module binary_to_gray_tb;
    reg  [3:0] binary;
    wire [3:0] gray;
    integer i;

    binary_to_gray dut (
        .binary(binary),
        .gray(gray)
    );

    initial begin
        $display("Binary | Gray");
        $display("--------------");
        for (i = 0; i < 16; i = i + 1) begin
            binary = i;
            #10;
            $display("%b | %b", binary, gray);
        end
        $finish;
    end
endmodule
